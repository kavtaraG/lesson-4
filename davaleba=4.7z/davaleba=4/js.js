const addBtn = document.querySelector('#btn1');
const div =  document.querySelector('.main');

const arr = [
    {
        username: 'valodia',
        age: 18
    },{
        username: 'vano',
        age: 16
    },{
        username: 'grisha',
        age: 21
    },{
        username: 'misha',
        age: 20
    }
];

function inactiveBtn (){
    const delItem1 = document.querySelector('#btn');
    delItem1.setAttribute('id', 'btn');
    delItem1.setAttribute('submit',' ');
}

function inactiveBtn2 (){
    const delItem2 = document.querySelector('#btn1');
    delItem2.setAttribute('id', 'btn');
    delItem2.setAttribute('submit',' ');
}

function addItem(){
    // const delItem = key.username;
    // const delItem1 = document.querySelector('li');
    // let keyItem = li.textContent;
    // li.textContent = key.username;
    // // const mySet = new Set();
    // // mySet.add(key.username);
    // // console.log(mySet, delItem1);
    // if(keyItem === delItem1){
    //     // console.log(key);
    //     let El = document.createElement('li');
    //     delItem1.appendChild(li);
    //     li.textContent = key.username;
    // }
    
    // arr.forEach(key =>{
    //     console.log(key.username);
    //     if(delItem1 = key.username){
    //         delItem1.add();
    //     }
        
    // });

    
    
}

addBtn.addEventListener('click', function addItem(event){
    
    const ul = document.querySelector('ul');
    const li = document.createElement('li');
    ul.appendChild(li);
   
    // arr.textContent = key.username;
    // const liElement = li.textContent;
    // const arrKey = key.username;
    // liElement = arrKey;
    // if(event.target.clicked){
    //     addBtn.add(key.username);
    // }

    console.log(event);
    newArr;
})

function removeItem(){
    const delItem2 = document.querySelector('li'); 
    
    
    delItem2.remove();
}
removeItem;


let newArr = function(){
    inactiveBtn;
    inactiveBtn2;
    // addItem;
    // removeItem;
    
    arr.forEach(key => {

            const mainDiv = document.querySelector('.main');
            const delItem1 = document.querySelector('#btn');
            const delItem2 = document.querySelector('#btn');
            const ul = document.createElement('ul');
            const li = document.createElement('li');
            
            
        
        if(key.age >= 18){
            
            mainDiv.appendChild(ul);
            ul.appendChild(li);
            li.textContent = key.username;
            delItem1.setAttribute('id', 'btn');
            delItem2.setAttribute('id', 'btn');
            // btn.setAttribute('id', 'btn1');
            console.log(key.username);
        }
    })
}

console.log(newArr());